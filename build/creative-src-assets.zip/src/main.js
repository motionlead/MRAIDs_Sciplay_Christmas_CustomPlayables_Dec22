// Automatically tracks the seconds
var tracking = require("./tracking");
var Track = require("./trackings.js");
const Video = require("./video");
const Carousel = require("./carousel");
const MultipleSpritesheet = require("./multipleSpritesheet");

var track = new Track();

// Get the width and height of the canvas
var width = stage.canvas.width;
var height = stage.canvas.height;

// Sbottomthands
var c = createjs;
var images = ad.assets.images;

// Create scaled container, the scaled container is used to avoid scaling each
// elements one by one
var sc = new c.Container();
// - Scale it
sc.scaleX = width / 640;
sc.scaleY = sc.scaleX;
// - Add it to the stage
stage.addChild(sc);
// - Update the width and height to be scaled according to the scaled container
width /= sc.scaleX;
height /= sc.scaleY;

// Create the close button
var cc = sc.clone();
stage.addChild(cc);

// Handle close button
if (window.mraid && window.mraid.useCustomClose) {
  // Disable default close button
  window.mraid.useCustomClose(true);

  // Setup close button
  var closeButton = new c.Bitmap(images.cross);
  closeButton.regX = images.cross.width / 2;
  closeButton.regY = images.cross.height / 2;
  closeButton.x = width - images.cross.width;
  closeButton.y = 50;
  cc.addChild(closeButton);

  closeButton.on("click", function () {
    ad.close();
  });
} else {
  // Nothing to do here, non-mraid interstitials already have a close button
}

// Add tracking for the first interaction on the scaled container
tracking.setupFirstInteractionTracking(sc);
track.track("display");

var timeoutIds = [5, 10, 15].map(function (time) {
  return setTimeout(function () {
    track.track("time" + time);
  }, time * 1000);
});

/*~~~~~~~~~~~ START CODE HERE ~~~~~~~~~~~*/

var bgShape = new c.Shape();
bgShape.graphics.beginFill("#000").drawRect(0, 0, width, height);
bgShape.alpha = 1;

var videoClicker = new c.Shape();
videoClicker.graphics.beginFill("#fff").drawRect(0, 0, width, height);
videoClicker.alpha = 0;

var bg = new c.Bitmap(images.bg);
bg.regX = bg.image.width / 2;
bg.regY = bg.image.height / 2;
bg.x = width / 2;
bg.y = height / 2;
bg.alpha = 1;
bg.name = "bg";

var bg_carrousel = new c.Bitmap(images.bg_carrousel);
bg_carrousel.regX = bg_carrousel.image.width / 2;
bg_carrousel.regY = bg_carrousel.image.height / 2;
bg_carrousel.x = width / 2;
bg_carrousel.y = bg.y;
bg_carrousel.alpha = 0;
bg_carrousel.name = "bg_carrousel";

//////////////////// Video ////////////////////

const onEnded = () => console.log("video Ended");
const onError = () => console.log("video Error");

const onTimeOut = (time) => {
  video.stop();
  endScreen();
};

const videoParameters = {
  src:
    "https://cdn-creatives.adikteev.com/coded_creative_videos/Funplus_GOG_CreativeConcept_Dec20_320x480.mp4",
  regX: 0.5,
  regY: 0.5,
  onEnded,
  onError,
  onTimeOut,
  timeValue: 8,
  playbackRate: 1,
  splashScreen: "splashScreen",
};

const video = new Video(videoParameters);
video.x = width / 2;
video.y = height / 2;
video.scaleX = video.scaleY = 1;
// video.play();
// video.stop();

// // controls
// addControlsVideo(video);

///////////////// CAROUSEL ////////////////

const onCenteredFadeObjects = (objects) => {
  console.log("onCenteredFadeObjects objects: ", objects);
};
const onCenteredObject = (object) => {
  console.log("onCenteredObject object: ", object);
};

// const fadeObjects = [
//   new c.Bitmap(images.bullet_1),
//   new c.Bitmap(images.bullet_2),
//   new c.Bitmap(images.bullet_3),
//   new c.Bitmap(images.bullet_4),
//   new c.Bitmap(images.bullet_5),
//   new c.Bitmap(images.bullet_6),
//   new c.Bitmap(images.bullet_7),
//   new c.Bitmap(images.bullet_8),
// ];
// const bullets = new c.Container();
// fadeObjects.forEach((fadeObject) => {
//   fadeObject.regX = fadeObject.image.width / 2;
//   fadeObject.regY = fadeObject.image.height / 2;
//   bullets.x = width / 2;
//   bullets.y = bg.y - bg.image.height * 0.12 + bg_carrousel.image.height * 0.85;
//   bullets.alpha = 0;
//   bullets.addChild(fadeObject);
// });

const carouselParameters = {
  images: [
    "card_1",
    "card_2",
    "card_3",
    "card_4",
    "card_5",
    "card_6",
    "card_7",
    "card_8",
  ],
  // urls: [
  //   "https://www.google.com/?q=1",
  //   "https://www.google.com/?q=2",
  //   "https://www.google.com/?q=3",
  //   "https://www.google.com/?q=1",
  //   "https://www.google.com/?q=2",
  //   "https://www.google.com/?q=3",
  // ],
  // videoWidth: 640,
  // videoHeight: 360,
  // splashScreens: ["", "asset_1", "", "asset_2", "", "asset_1"],
  // debug: true,
  isCyclic: true,
  startIndex: 1,
  masked: false,
  scaleUnfocus: 0.2,
  alignFocusV: 50, // vertically align the focused element. From 0 (top) to 100 (bottom)
  alignUnfocus: 50, // vertically align the unfocused elements. From 0 (top) to 100 (bottom)
  alignFocusH: 50, // horizontally align the focused element. From 0 (left) to 100 (right)
  opacityUnfocus: 0.5, // from 0 to 1
  speedDeceleration: 0.92,
  width: width * 0.8,
  height: height * 0.45,
  showSoundButtons: false,
  gap: 0,
  name: "carousel", // useful for tracking when several carousels at once
  speedThreshold: 0.02,
  // fadeObjects: fadeObjects.map((fadeObject) => [fadeObject]),
  // onCenteredFadeObjects,
  // onCenteredObject,
  autoPlay: 1.5, // period in seconds
  // languageSuffix: 'en', // getMobileLanguage(),
  isVertical: false,
  tooltip: "hand",
  layout: "3d",
};

const carousel = new Carousel(carouselParameters);
carousel.regX = carousel.width / 2;
carousel.regY = carousel.height / 2;
carousel.x = width * 0.5;
carousel.alpha = 0;
carousel.y = bg_carrousel.y;

///////////////// SPRITESHEET////////////////
const msParameters = {
  names: ["sprite_1", "sprite_2"],
  regX: 0.5,
  regY: 0.5,
  framerate: 15,
  // onAnimationEnd,
};

const particules = new MultipleSpritesheet(msParameters);
particules.x = width / 2;
particules.y = height / 2;
particules.scaleX = particules.scaleY = 2;
particules.alpha = 0;
sc.addChild(particules);

var gradient = new c.Bitmap(images.gradient);
gradient.regX = gradient.image.width / 2;
gradient.regY = gradient.image.height / 2;
gradient.x = width / 2;
gradient.y = height / 2;
gradient.alpha = 1;
gradient.name = "gradient";

var logo = new c.Bitmap(images.logo);
logo.regX = logo.image.width / 2;
logo.regY = logo.image.height / 2;
logo.x = width / 2;
logo.y = height * 0.1;
logo.alpha = 0;
logo.name = "logo";

var wording = new c.Bitmap(images.wording);
wording.regX = wording.image.width / 2;
wording.regY = wording.image.height / 2;
wording.x = width / 2;
wording.y = bg.y + bg.image.height * 0.2;
wording.scaleX = wording.scaleY = 2;
wording.alpha = 0;
wording.name = "wording";

var cta = new c.Bitmap(images.cta);
cta.regX = cta.image.width / 2;
cta.regY = cta.image.height / 2;
cta.x = width / 2;
cta.y = wording.y + wording.image.height * 0.8;
cta.scaleX = cta.scaleY = 2;
cta.alpha = 0;
cta.name = "cta";

var soldier = new c.Bitmap(images.soldier);
soldier.regX = soldier.image.width / 2;
soldier.regY = soldier.image.height;
soldier.x = -soldier.image.width * soldier.scaleX;
soldier.y = height + soldier.image.height * 0.5;
soldier.scaleX = soldier.scaleY = 1.6;
soldier.alpha = 1;
soldier.name = "soldier";

var glow = new c.Bitmap(images.glow);
glow.regX = glow.image.width / 2;
glow.regY = glow.image.height / 2;
glow.x = width / 2;
glow.y = video.y;
glow.scaleX = glow.scaleY = 0;
glow.alpha = 1;
glow.name = "glow";

sc.addChild(
  bgShape,
  bg,
  bg_carrousel,
  particules,
  carousel,
  // bullets,
  video,
  videoClicker,
  soldier,
  gradient,
  wording,
  cta,
  glow,
  logo
);
var clickable = [
  bgShape,
  bg,
  bg_carrousel,
  // bullets,
  soldier,
  gradient,
  wording,
  cta,
  glow,
  logo,
];

c.Ticker.addEventListener("tick", handleTick);
function handleTick() {
  carousel.y = bg_carrousel.y;
}

// ANIMATIONS
c.Tween.get(logo).to({ alpha: 1 }, 1000, c.Ease.quadOut);

var clickTime = 0;
var videoIsClicked = false;

setTimeout(function () {
  videoClicker.alpha = 0.01;
}, 5000);

videoClicker.on("click", function () {
  var now = new Date().getTime();
  if (now - clickTime > 200 && !videoIsClicked) {
    videoIsClicked = true;
    videoClicker.visible = false;
    video.play();
  }
  clickTime = now;
});

function endScreen() {
  c.Tween.get(video).to({ alpha: 0 }, 500, c.Ease.quadOut);
  c.Tween.get(particules).to({ alpha: 1 }, 500, c.Ease.quadOut);
  c.Tween.get(glow).to(
    { scaleX: 15, scaleY: 15, alpha: 0 },
    500,
    c.Ease.quadOut
  );

  c.Tween.get(soldier).to(
    { x: width / 2, y: gradient.y + gradient.image.height * 0.3 },
    500,
    c.Ease.quadOut
  );

  c.Tween.get(bg_carrousel).to(
    { y: bg.y - bg.image.height * 0.12, alpha: 1 },
    500,
    c.Ease.quadOut
  );

  c.Tween.get(carousel).to({ alpha: 1 }, 500, c.Ease.quadOut);

  // c.Tween.get(bullets).wait(1000).to({ alpha: 1 }, 500, c.Ease.quadOut);

  c.Tween.get(wording)
    .wait(500)
    .to({ scaleX: 0.8, scaleY: 0.8, alpha: 1 }, 250, c.Ease.quadIn)
    .to({ scaleX: 1, scaleY: 1 }, 125, c.Ease.quadOut)
    .call(function () {
      c.Tween.get(cta)
        .to({ scaleX: 0.8, scaleY: 0.8, alpha: 1 }, 250, c.Ease.quadIn)
        .to({ scaleX: 1, scaleY: 1 }, 125, c.Ease.quadOut)
        .call(ctaBounce);
    });
}

function ctaBounce() {
  const scale1 = 1;
  const scale2 = scale1 + 0.2;
  const scale3 = scale1 - 0.2;
  const scale4 = scale1 + 0.1;
  const scale5 = scale1 - 0.1;

  c.Tween.get(cta, { loop: true })
    .wait(1000)
    .to({ scaleX: scale1, scaleY: scale1 }, 500, c.Ease.quadOut)
    .to({ scaleX: scale2, scaleY: scale2 }, 250, c.Ease.quadOut)
    .to({ scaleX: scale3, scaleY: scale3 }, 150, c.Ease.quadOut)
    .to({ scaleX: scale4, scaleY: scale4 }, 150, c.Ease.quadOut)
    .to({ scaleX: scale5, scaleY: scale5 }, 100, c.Ease.quadOut)
    .to({ scaleX: scale1, scaleY: scale1 }, 75, c.Ease.quadOut);
}

/*~~~~~~~~~~~~ END CODE HERE ~~~~~~~~~~~~*/

clickable.forEach(function (element) {
  element.on("click", function () {
    var now = new Date().getTime();
    if (now - clickTime > 200) {
      track.track("adOpen_click_on_" + element.name);
      ad.open();
    }
    clickTime = now;
  });
});

// Restarts the ad on resize event
ad.on("resize", function () {
  ad.restart();
});

// Remove all event listeners added on DOM objects in here (e.g. accelerometer,
// etc)
ad.on("cleanup", function () {
  // No need to remove events listeners on EaselJS objects
});
